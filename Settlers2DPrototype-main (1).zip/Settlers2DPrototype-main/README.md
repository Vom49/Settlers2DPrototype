# Settlers2DPrototype
Group 42 Settlers Unity Prototype
Made in Unitiy 2021.3.19.f1
